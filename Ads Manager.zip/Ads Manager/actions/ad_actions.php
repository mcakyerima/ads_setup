<?php

/**
 * Admin Actions Handler
 * Handles ad creation, updates, deletes, and status changes
 */

session_start();
header('Content-Type: application/json');

require_once '../config.php';
require_once '../includes/db.php';

// Fallback for BASE_URL if not defined in config.php
if (!defined('BASE_URL')) {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $path = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/');
    define('BASE_URL', $protocol . '://' . $host . $path);
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'fetch':
            fetchAllAds($pdo);
            break;

        case 'create':
            createAd($pdo);
            break;

        case 'update':
            updateAd($pdo);
            break;

        case 'delete':
            deleteAd($pdo);
            break;

        case 'toggle':
            toggleAdStatus($pdo);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

/**
 * Fetch all ads (including inactive)
 */
function fetchAllAds($pdo)
{
    $filter = $_GET['filter'] ?? 'all';

    $sql = "SELECT * FROM ads";
    if ($filter === 'active') {
        $sql .= " WHERE is_active = 1";
    } elseif ($filter === 'inactive') {
        $sql .= " WHERE is_active = 0";
    }
    $sql .= " ORDER BY created_at DESC";

    $stmt = $pdo->query($sql);
    $ads = $stmt->fetchAll();

    // Format image URLs with full BASE_URL
    foreach ($ads as &$ad) {
        if (!empty($ad['image'])) {
            // Use full URL with BASE_URL constant for proper display
            $ad['image_url'] = BASE_URL . '/uploads/' . basename($ad['image']);
        } else {
            $ad['image_url'] = '';
        }
    }

    echo json_encode([
        'success' => true,
        'ads' => $ads
    ]);
}

/**
 * Create new ad
 */
function createAd($pdo)
{
    $title = $_POST['title'] ?? '';
    $body = $_POST['body'] ?? '';
    $message = $_POST['message'] ?? '';
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    if (empty($title) || empty($body) || empty($message)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        return;
    }

    // Handle image upload
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'message' => 'Image is required']);
        return;
    }

    $file = $_FILES['image'];
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];

    if (!in_array($file['type'], $allowedTypes)) {
        echo json_encode(['success' => false, 'message' => 'Only JPG, PNG, and GIF images allowed']);
        return;
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'Image must be less than 5MB']);
        return;
    }

    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('ad_') . '_' . time() . '.' . $extension;
    $uploadPath = __DIR__ . '/../uploads/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        echo json_encode(['success' => false, 'message' => 'Failed to upload image']);
        return;
    }

    // Insert into database
    $stmt = $pdo->prepare("
        INSERT INTO ads (title, body, message, image, is_active)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$title, $body, $message, $filename, $isActive]);

    echo json_encode([
        'success' => true,
        'message' => 'Ad created successfully',
        'ad_id' => $pdo->lastInsertId()
    ]);
}

/**
 * Update existing ad
 */
function updateAd($pdo)
{
    $id = $_POST['id'] ?? 0;
    $title = $_POST['title'] ?? '';
    $body = $_POST['body'] ?? '';
    $message = $_POST['message'] ?? '';

    if (!$id || empty($title) || empty($body) || empty($message)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        return;
    }

    // Check if new image is uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['image'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];

        if (!in_array($file['type'], $allowedTypes)) {
            echo json_encode(['success' => false, 'message' => 'Invalid image type']);
            return;
        }

        // Get old image
        $stmt = $pdo->prepare("SELECT image FROM ads WHERE id = ?");
        $stmt->execute([$id]);
        $oldAd = $stmt->fetch();

        if ($oldAd) {
            // Delete old image
            $oldImagePath = __DIR__ . '/../uploads/' . basename($oldAd['image']);
            if (file_exists($oldImagePath)) {
                unlink($oldImagePath);
            }
        }

        // Upload new image
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid('ad_') . '_' . time() . '.' . $extension;
        $uploadPath = __DIR__ . '/../uploads/' . $filename;

        if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
            echo json_encode(['success' => false, 'message' => 'Failed to upload new image']);
            return;
        }

        // Update with new image
        $stmt = $pdo->prepare("
            UPDATE ads 
            SET title = ?, body = ?, message = ?, image = ?
            WHERE id = ?
        ");
        $stmt->execute([$title, $body, $message, $filename, $id]);
    } else {
        // Update without changing image
        $stmt = $pdo->prepare("
            UPDATE ads 
            SET title = ?, body = ?, message = ?
            WHERE id = ?
        ");
        $stmt->execute([$title, $body, $message, $id]);
    }

    echo json_encode([
        'success' => true,
        'message' => 'Ad updated successfully'
    ]);
}

/**
 * Delete ad
 */
function deleteAd($pdo)
{
    $id = $_POST['id'] ?? $_GET['id'] ?? 0;

    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Ad ID required']);
        return;
    }

    // Get image filename
    $stmt = $pdo->prepare("SELECT image FROM ads WHERE id = ?");
    $stmt->execute([$id]);
    $ad = $stmt->fetch();

    if (!$ad) {
        echo json_encode(['success' => false, 'message' => 'Ad not found']);
        return;
    }

    // Delete image file
    $imagePath = __DIR__ . '/../uploads/' . basename($ad['image']);
    if (file_exists($imagePath)) {
        unlink($imagePath);
    }

    // Delete from database
    $stmt = $pdo->prepare("DELETE FROM ads WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode([
        'success' => true,
        'message' => 'Ad deleted successfully'
    ]);
}

/**
 * Toggle ad active status
 */
function toggleAdStatus($pdo)
{
    $id = $_POST['id'] ?? $_GET['id'] ?? 0;

    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Ad ID required']);
        return;
    }

    $stmt = $pdo->prepare("UPDATE ads SET is_active = NOT is_active WHERE id = ?");
    $stmt->execute([$id]);

    // Get new status
    $stmt = $pdo->prepare("SELECT is_active FROM ads WHERE id = ?");
    $stmt->execute([$id]);
    $ad = $stmt->fetch();

    echo json_encode([
        'success' => true,
        'message' => 'Status updated',
        'is_active' => (bool)$ad['is_active']
    ]);
}
