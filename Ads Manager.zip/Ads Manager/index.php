<?php

/**
 * KimeData Ads Manager
 * Professional PHP-based advertisement management system
 * Compatible with XAMPP and cPanel hosting
 */

session_start();

// Check if database is configured
$configFile = __DIR__ . '/config.php';
$isConfigured = file_exists($configFile);

if ($isConfigured) {
    require_once $configFile;
    require_once 'includes/db.php';

    // Check if user is logged in
    if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
        // Show login page
        include 'login.php';
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ads Manager</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <?php if (!$isConfigured): ?>
        <!-- Database Setup Page -->
        <div class="setup-container">
            <div class="setup-card">
                <div class="setup-header">
                    <i class="fas fa-database"></i>
                    <h1>Database Configuration</h1>
                    <p>Connect to your MySQL database to get started</p>
                </div>

                <form id="setupForm" class="setup-form">
                    <div class="form-group">
                        <label><i class="fas fa-server"></i> Database Host</label>
                        <input type="text" name="db_host" value="localhost" required>
                        <small>Usually "localhost" for local servers</small>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-database"></i> Database Name</label>
                        <input type="text" name="db_name" placeholder="ads_manager" required>
                        <small>Name of your MySQL database</small>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Database Username</label>
                        <input type="text" name="db_user" placeholder="root" required>
                        <small>MySQL username (default: root for XAMPP)</small>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-key"></i> Database Password</label>
                        <div style="position: relative;">
                            <input type="password" id="db_password" name="db_password" placeholder="" style="padding-right: 45px;">
                            <i class="fas fa-eye" id="toggleDbPassword" onclick="togglePassword('db_password', 'toggleDbPassword')" style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #6b7280;"></i>
                        </div>
                        <small>MySQL password (empty for XAMPP by default)</small>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> WhatsApp Contact Number (for Ads)</label>
                        <input type="text" name="whatsapp_number" placeholder="2348066968620" required>
                        <small>WhatsApp number for customer contact (with country code, no + or spaces)</small>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-user-shield"></i> Admin Username</label>
                        <input type="text" name="admin_username" placeholder="admin" required>
                        <small>Username for accessing the ads manager</small>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Admin Password</label>
                        <div style="position: relative;">
                            <input type="password" id="admin_password" name="admin_password" placeholder="" required minlength="6" style="padding-right: 45px;">
                            <i class="fas fa-eye" id="toggleAdminPassword" onclick="togglePassword('admin_password', 'toggleAdminPassword')" style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #6b7280;"></i>
                        </div>
                        <small>Password for admin access (minimum 6 characters)</small>
                    </div>

                    <button type="submit" class="btn-primary">
                        <i class="fas fa-plug"></i> Connect Database
                    </button>

                    <div id="setupStatus" class="status-message"></div>
                </form>

                <div class="setup-info">
                    <h3><i class="fas fa-info-circle"></i> Setup Instructions</h3>
                    <ul>
                        <li>Make sure MySQL server is running</li>
                        <li>Create a database first (via phpMyAdmin or cPanel)</li>
                        <li>Enter your database credentials above</li>
                        <li>System will auto-create tables and folders</li>
                    </ul>
                </div>
            </div>
        </div>

        <script>
            function togglePassword(inputId, iconId) {
                const input = document.getElementById(inputId);
                const icon = document.getElementById(iconId);

                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            }
        </script>
        <script src="assets/js/setup.js"></script>
    <?php else: ?>
        <!-- Main Ads Manager -->
        <div class="app-container">
            <!-- Fixed Header -->
            <header class="app-header">
                <div class="header-content">
                    <div class="header-left">
                        <i class="fas fa-bullhorn"></i>
                        <h1>Ads Manager</h1>
                    </div>
                    <div class="header-right">
                        <span class="stats-badge">
                            <i class="fas fa-ad"></i>
                            <span id="totalAds">0</span> Ads
                        </span>
                        <button onclick="location.href='settings.php'" class="btn-settings">
                            <i class="fas fa-cog"></i> Settings
                        </button>
                    </div>
                </div>
            </header>

            <!-- Main Content Grid -->
            <div class="main-content">
                <!-- Left Side: Upload Form -->
                <div class="upload-section">
                    <div class="section-card">
                        <h2><i class="fas fa-plus-circle"></i> Create New Ad</h2>

                        <form id="adForm" enctype="multipart/form-data">
                            <!-- Image Upload with Drag & Drop -->
                            <div class="form-group">
                                <label>Ad Image *</label>
                                <div class="dropzone" id="dropzone">
                                    <i class="fas fa-cloud-upload-alt"></i>
                                    <p>Drag & drop image here or click to browse</p>
                                    <small>JPG, PNG, GIF (Max 5MB)</small>
                                </div>
                                <input type="file" id="imageInput" name="image" accept="image/*" style="display:none" required>

                                <!-- Image Preview -->
                                <div id="imagePreview" class="image-preview" style="display:none">
                                    <img id="previewImg" src="" alt="Preview">
                                    <button type="button" class="btn-remove" onclick="removeImage()">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Ad Title *</label>
                                <input type="text" name="title" id="titleInput" maxlength="60" placeholder="e.g., Special Christmas Discount!" required>
                                <div class="char-counter"><span id="titleCount">0</span>/60</div>
                            </div>

                            <div class="form-group">
                                <label>Ad Description *</label>
                                <textarea name="body" id="bodyInput" maxlength="150" rows="3" placeholder="Brief description of your offer..." required></textarea>
                                <div class="char-counter"><span id="bodyCount">0</span>/150</div>
                            </div>

                            <div class="form-group">
                                <label>WhatsApp Message *</label>
                                <textarea name="message" id="messageInput" maxlength="200" rows="3" placeholder="Hello! I would like to get more details about this offer" required>Hello! I would like to get more details about this offer</textarea>
                                <div class="char-counter"><span id="messageCount">0</span>/200</div>
                            </div>

                            <div class="form-group">
                                <label class="checkbox-label">
                                    <input type="checkbox" name="is_active" checked>
                                    <span>Publish immediately</span>
                                </label>
                            </div>

                            <button type="submit" class="btn-upload">
                                <i class="fas fa-upload"></i> Upload Advertisement
                            </button>

                            <!-- Progress Bar -->
                            <div id="uploadProgress" class="progress-container" style="display:none">
                                <div class="progress-bar">
                                    <div id="progressFill" class="progress-fill"></div>
                                </div>
                                <p id="progressText">Uploading... 0%</p>
                            </div>

                            <div id="uploadStatus" class="status-message"></div>
                        </form>
                    </div>
                </div>

                <!-- Right Side: Ads List -->
                <div class="ads-section">
                    <div class="section-card">
                        <div class="ads-header">
                            <h2><i class="fas fa-list"></i> Your Advertisements</h2>
                            <div class="filter-buttons">
                                <button class="filter-btn active" data-filter="all">All</button>
                                <button class="filter-btn" data-filter="active">Active</button>
                                <button class="filter-btn" data-filter="inactive">Inactive</button>
                            </div>
                        </div>

                        <div id="adsGrid" class="ads-grid">
                            <div class="loading-spinner">
                                <i class="fas fa-spinner fa-spin"></i>
                                <p>Loading ads...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Modal -->
        <div id="editModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-edit"></i> Edit Advertisement</h3>
                    <button class="modal-close" onclick="closeEditModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <form id="editForm">
                    <input type="hidden" id="editAdId" name="id">

                    <div class="form-group">
                        <label>Current Image</label>
                        <div class="current-image">
                            <img id="editCurrentImage" src="" alt="Current">
                        </div>
                        <label>Change Image (optional)</label>
                        <input type="file" name="image" accept="image/*">
                    </div>

                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" id="editTitle" name="title" maxlength="60" required>
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea id="editBody" name="body" maxlength="150" rows="3" required></textarea>
                    </div>

                    <div class="form-group">
                        <label>WhatsApp Message</label>
                        <textarea id="editMessage" name="message" maxlength="200" rows="3" required></textarea>
                    </div>

                    <div class="modal-actions">
                        <button type="button" class="btn-secondary" onclick="closeEditModal()">Cancel</button>
                        <button type="submit" class="btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>

        <script src="assets/js/main.js?v=<?php echo time(); ?>"></script>
    <?php endif; ?>
</body>

</html>