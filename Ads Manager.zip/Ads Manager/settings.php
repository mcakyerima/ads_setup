<?php

/**
 * Settings Page
 * Manage database configuration and system settings
 */

session_start();
require_once 'config.php';
require_once 'includes/db.php';

// Check authentication
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header('Location: index.php');
    exit;
}

// Handle WhatsApp number update
$updateMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_whatsapp'])) {
    $newWhatsapp = trim($_POST['whatsapp_number']);
    if (!empty($newWhatsapp)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) 
                VALUES ('whatsapp_number', ?) 
                ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = NOW()");
            $stmt->execute([$newWhatsapp, $newWhatsapp]);
            $updateMessage = '<div style="padding: 15px; background: #d1fae5; border-left: 4px solid #10b981; border-radius: 8px; margin: 20px 0;">
                <p style="color: #065f46; font-size: 14px; margin: 0;">
                    <i class="fas fa-check-circle"></i> WhatsApp number updated successfully!
                </p>
            </div>';
        } catch (PDOException $e) {
            $updateMessage = '<div style="padding: 15px; background: #fee2e2; border-left: 4px solid #ef4444; border-radius: 8px; margin: 20px 0;">
                <p style="color: #991b1b; font-size: 14px; margin: 0;">
                    <i class="fas fa-exclamation-circle"></i> Error updating WhatsApp number: ' . $e->getMessage() . '
                </p>
            </div>';
        }
    }
}

// Fetch current WhatsApp number
$currentWhatsapp = '2348066968620'; // default
try {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'whatsapp_number' LIMIT 1");
    $stmt->execute();
    $row = $stmt->fetch();
    if ($row) {
        $currentWhatsapp = $row['setting_value'];
    }
} catch (PDOException $e) {
    // Keep default if error
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Ads Manager</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="setup-container">
        <div class="setup-card">
            <div class="setup-header">
                <i class="fas fa-cog"></i>
                <h1>System Settings</h1>
                <p>Manage your database and system configuration</p>
            </div>

            <div class="settings-info">
                <?php echo $updateMessage; ?>

                <h3><i class="fas fa-database"></i> Current Database Configuration</h3>
                <table style="width: 100%; margin: 20px 0; font-size: 14px;">
                    <tr>
                        <td style="padding: 10px 0; color: #6b7280;">Host:</td>
                        <td style="padding: 10px 0; font-weight: 600;"><?php echo DB_HOST; ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; color: #6b7280;">Database:</td>
                        <td style="padding: 10px 0; font-weight: 600;"><?php echo DB_NAME; ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; color: #6b7280;">Username:</td>
                        <td style="padding: 10px 0; font-weight: 600;"><?php echo DB_USER; ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; color: #6b7280;">Base URL:</td>
                        <td style="padding: 10px 0; font-weight: 600; word-break: break-all;"><?php echo BASE_URL; ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; color: #6b7280;">API Endpoint:</td>
                        <td style="padding: 10px 0; font-weight: 600; word-break: break-all;"><?php echo BASE_URL . '/api/ads.php'; ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; color: #6b7280;">WhatsApp Contact:</td>
                        <td style="padding: 10px 0; font-weight: 600;"><?php echo htmlspecialchars($currentWhatsapp); ?></td>
                    </tr>
                </table>

                <div style="padding: 15px; background: #fef3c7; border-left: 4px solid #f59e0b; border-radius: 8px; margin: 20px 0;">
                    <p style="color: #92400e; font-size: 14px; margin: 0;">
                        <i class="fas fa-info-circle"></i>
                        <strong>Important:</strong> Update your mobile app's API URL to:
                        <code style="background: white; padding: 2px 6px; border-radius: 4px; display: inline-block; margin-top: 5px;"><?php echo BASE_URL . '/api/ads.php'; ?></code>
                    </p>
                </div>

                <h3 style="margin-top: 30px;"><i class="fas fa-phone"></i> Update WhatsApp Contact</h3>
                <form method="POST" style="margin-top: 15px;">
                    <div style="background: #f9fafb; padding: 20px; border-radius: 8px;">
                        <label style="display: block; margin-bottom: 10px; color: #374151; font-weight: 600;">
                            <i class="fas fa-phone"></i> WhatsApp Number (with country code, no + or spaces)
                        </label>
                        <input type="text"
                            name="whatsapp_number"
                            value="<?php echo htmlspecialchars($currentWhatsapp); ?>"
                            placeholder="2348066968620"
                            required
                            style="width: 100%; padding: 12px; border: 2px solid #d1d5db; border-radius: 8px; font-size: 14px;">
                        <small style="display: block; margin-top: 8px; color: #6b7280;">
                            Example: 2348066968620 (Nigeria), 14155552671 (USA)
                        </small>
                        <button type="submit"
                            name="update_whatsapp"
                            style="margin-top: 15px; padding: 12px 24px; background: #0286FF; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 14px;">
                            <i class="fas fa-save"></i> Update WhatsApp Number
                        </button>
                    </div>
                </form>

                <?php
                // Get database statistics
                try {
                    $stmt = $pdo->query("SELECT 
                        COUNT(*) as total_ads,
                        SUM(is_active = 1) as active_ads,
                        SUM(is_active = 0) as inactive_ads,
                        SUM(click_count) as total_clicks
                    FROM ads");
                    $stats = $stmt->fetch();
                ?>

                    <h3 style="margin-top: 30px;"><i class="fas fa-chart-bar"></i> Statistics</h3>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-top: 15px;">
                        <div style="padding: 15px; background: #f9fafb; border-radius: 8px; text-align: center;">
                            <div style="font-size: 32px; font-weight: 700; color: #0286FF;"><?php echo $stats['total_ads']; ?></div>
                            <div style="color: #6b7280; font-size: 14px;">Total Ads</div>
                        </div>
                        <div style="padding: 15px; background: #f9fafb; border-radius: 8px; text-align: center;">
                            <div style="font-size: 32px; font-weight: 700; color: #10b981;"><?php echo $stats['active_ads']; ?></div>
                            <div style="color: #6b7280; font-size: 14px;">Active Ads</div>
                        </div>
                        <div style="padding: 15px; background: #f9fafb; border-radius: 8px; text-align: center;">
                            <div style="font-size: 32px; font-weight: 700; color: #ef4444;"><?php echo $stats['inactive_ads']; ?></div>
                            <div style="color: #6b7280; font-size: 14px;">Inactive Ads</div>
                        </div>
                        <div style="padding: 15px; background: #f9fafb; border-radius: 8px; text-align: center;">
                            <div style="font-size: 32px; font-weight: 700; color: #6366f1;"><?php echo $stats['total_clicks']; ?></div>
                            <div style="color: #6b7280; font-size: 14px;">Total Clicks</div>
                        </div>
                    </div>

                <?php
                } catch (PDOException $e) {
                    echo '<p style="color: #ef4444; margin-top: 15px;">Error fetching statistics: ' . $e->getMessage() . '</p>';
                }
                ?>

                <h3 style="margin-top: 30px;"><i class="fas fa-key"></i> Change Password</h3>
                <form id="changePasswordForm" style="margin-top: 15px;">
                    <div style="background: #f9fafb; padding: 20px; border-radius: 8px;">
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 8px; color: #374151; font-weight: 600;">
                                <i class="fas fa-lock"></i> Current Password
                            </label>
                            <input type="password"
                                name="current_password"
                                placeholder="Enter current password"
                                required
                                style="width: 100%; padding: 12px; border: 2px solid #d1d5db; border-radius: 8px; font-size: 14px;">
                        </div>

                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 8px; color: #374151; font-weight: 600;">
                                <i class="fas fa-lock"></i> New Password
                            </label>
                            <input type="password"
                                name="new_password"
                                placeholder="Enter new password"
                                required
                                minlength="6"
                                style="width: 100%; padding: 12px; border: 2px solid #d1d5db; border-radius: 8px; font-size: 14px;">
                        </div>

                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 8px; color: #374151; font-weight: 600;">
                                <i class="fas fa-lock"></i> Confirm New Password
                            </label>
                            <input type="password"
                                name="confirm_password"
                                placeholder="Confirm new password"
                                required
                                minlength="6"
                                style="width: 100%; padding: 12px; border: 2px solid #d1d5db; border-radius: 8px; font-size: 14px;">
                        </div>

                        <small style="display: block; margin-bottom: 15px; color: #6b7280;">
                            Password must be at least 6 characters long
                        </small>

                        <button type="submit"
                            style="padding: 12px 24px; background: #0286FF; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 14px;">
                            <i class="fas fa-save"></i> Change Password
                        </button>

                        <div id="passwordStatus" style="margin-top: 15px;"></div>
                    </div>
                </form>

                <div style="margin-top: 30px; display: flex; gap: 10px; flex-wrap: wrap;">
                    <a href="index.php" class="btn-primary" style="flex: 1; display: inline-flex; align-items: center; justify-content: center; gap: 8px;">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                    <a href="javascript:void(0)" onclick="logout()" style="flex: 1; padding: 12px 24px; background: #ef4444; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; gap: 8px; transition: background 0.3s ease;">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>

                <div style="margin-top: 20px; padding-top: 20px; border-top: 2px solid #e5e7eb;">
                    <p style="color: #9ca3af; font-size: 12px; text-align: center;">
                        Ads Manager v1.0 | Powered by PHP & MySQL
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('changePasswordForm').addEventListener('submit', async function(e) {
            e.preventDefault();

            const formData = new FormData(this);
            formData.append('action', 'change_password');

            const button = this.querySelector('button');
            const statusDiv = document.getElementById('passwordStatus');

            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Changing...';

            try {
                const response = await fetch('auth.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    statusDiv.innerHTML = '<div style="padding: 12px; background: #d1fae5; border-left: 4px solid #10b981; border-radius: 8px;"><p style="color: #065f46; margin: 0;"><i class="fas fa-check-circle"></i> ' + result.message + '</p></div>';
                    this.reset();
                } else {
                    statusDiv.innerHTML = '<div style="padding: 12px; background: #fee2e2; border-left: 4px solid #ef4444; border-radius: 8px;"><p style="color: #991b1b; margin: 0;"><i class="fas fa-exclamation-circle"></i> ' + result.message + '</p></div>';
                }

                button.disabled = false;
                button.innerHTML = '<i class="fas fa-save"></i> Change Password';
            } catch (error) {
                statusDiv.innerHTML = '<div style="padding: 12px; background: #fee2e2; border-left: 4px solid #ef4444; border-radius: 8px;"><p style="color: #991b1b; margin: 0;"><i class="fas fa-exclamation-circle"></i> An error occurred. Please try again.</p></div>';
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-save"></i> Change Password';
            }
        });

        async function logout() {
            if (confirm('Are you sure you want to logout?')) {
                const formData = new FormData();
                formData.append('action', 'logout');

                try {
                    await fetch('auth.php', {
                        method: 'POST',
                        body: formData
                    });
                    window.location.href = 'index.php';
                } catch (error) {
                    alert('Error logging out');
                }
            }
        }
    </script>
</body>

</html>