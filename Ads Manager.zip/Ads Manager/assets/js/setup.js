/**
 * Setup Page JavaScript
 * Handles database configuration
 */

document.addEventListener('DOMContentLoaded', function() {
    const setupForm = document.getElementById('setupForm');
    const setupStatus = document.getElementById('setupStatus');
    
    setupForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(setupForm);
        const submitBtn = setupForm.querySelector('button[type="submit"]');
        
        // Disable button
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting...';
        
        // Clear previous status
        setupStatus.className = 'status-message';
        setupStatus.textContent = '';
        
        try {
            const response = await fetch('setup.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                setupStatus.className = 'status-message show success';
                setupStatus.innerHTML = '<i class="fas fa-check-circle"></i> ' + data.message;
                
                // Redirect after 2 seconds
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            } else {
                setupStatus.className = 'status-message show error';
                setupStatus.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + data.message;
                
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-plug"></i> Connect Database';
            }
        } catch (error) {
            setupStatus.className = 'status-message show error';
            setupStatus.innerHTML = '<i class="fas fa-exclamation-circle"></i> Network error: ' + error.message;
            
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-plug"></i> Connect Database';
        }
    });
});
