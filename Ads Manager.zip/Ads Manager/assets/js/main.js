/**
 * Main Application JavaScript
 * Handles ad management, upload, edit, delete, and filtering
 */

let currentFilter = 'all';

document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupDropzone();
    setupCharCounters();
    setupUploadForm();
    setupFilterButtons();
    loadAds();
}

/**
 * Dropzone Setup
 */
function setupDropzone() {
    const dropzone = document.getElementById('dropzone');
    const imageInput = document.getElementById('imageInput');
    const imagePreview = document.getElementById('imagePreview');
    const previewImg = document.getElementById('previewImg');
    
    dropzone.addEventListener('click', () => imageInput.click());
    
    dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
    });
    
    dropzone.addEventListener('dragleave', () => {
        dropzone.classList.remove('dragover');
    });
    
    dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleImageSelect(files[0]);
        }
    });
    
    imageInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleImageSelect(e.target.files[0]);
        }
    });
}

function handleImageSelect(file) {
    if (!file.type.startsWith('image/')) {
        showStatus('error', 'Please select an image file');
        return;
    }
    
    if (file.size > 5 * 1024 * 1024) {
        showStatus('error', 'Image must be less than 5MB');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
        document.getElementById('previewImg').src = e.target.result;
        document.getElementById('imagePreview').style.display = 'block';
        document.getElementById('dropzone').classList.add('has-file');
    };
    reader.readAsDataURL(file);
}

function removeImage() {
    document.getElementById('imageInput').value = '';
    document.getElementById('imagePreview').style.display = 'none';
    document.getElementById('dropzone').classList.remove('has-file');
}

/**
 * Character Counters
 */
function setupCharCounters() {
    const inputs = [
        { input: 'titleInput', counter: 'titleCount' },
        { input: 'bodyInput', counter: 'bodyCount' },
        { input: 'messageInput', counter: 'messageCount' }
    ];
    
    inputs.forEach(({ input, counter }) => {
        const inputEl = document.getElementById(input);
        const counterEl = document.getElementById(counter);
        
        // Set initial count for pre-populated fields
        if (inputEl && counterEl) {
            counterEl.textContent = inputEl.value.length;
        }
        
        inputEl.addEventListener('input', () => {
            counterEl.textContent = inputEl.value.length;
        });
    });
}

/**
 * Upload Form
 */
function setupUploadForm() {
    const form = document.getElementById('adForm');
    const uploadBtn = form.querySelector('button[type="submit"]');
    const progressContainer = document.getElementById('uploadProgress');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(form);
        formData.append('action', 'create');
        
        // Disable button and show progress
        uploadBtn.disabled = true;
        uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
        progressContainer.style.display = 'block';
        
        // Simulate progress
        let progress = 0;
        const progressInterval = setInterval(() => {
            progress += 10;
            if (progress <= 90) {
                updateProgress(progress);
            }
        }, 100);
        
        try {
            const response = await fetch('actions/ad_actions.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            clearInterval(progressInterval);
            updateProgress(100);
            
            if (data.success) {
                showStatus('success', data.message);
                
                // Reset form
                form.reset();
                removeImage();
                document.getElementById('titleCount').textContent = '0';
                document.getElementById('bodyCount').textContent = '0';
                document.getElementById('messageCount').textContent = '0';
                
                // Reload ads
                loadAds();
                
                // Hide progress after 2 seconds
                setTimeout(() => {
                    progressContainer.style.display = 'none';
                    updateProgress(0);
                }, 2000);
            } else {
                showStatus('error', data.message);
            }
        } catch (error) {
            clearInterval(progressInterval);
            showStatus('error', 'Upload failed: ' + error.message);
        } finally {
            uploadBtn.disabled = false;
            uploadBtn.innerHTML = '<i class="fas fa-upload"></i> Upload Advertisement';
        }
    });
}

function updateProgress(percent) {
    document.getElementById('progressFill').style.width = percent + '%';
    document.getElementById('progressText').textContent = `Uploading... ${percent}%`;
}

function showStatus(type, message) {
    const status = document.getElementById('uploadStatus');
    status.className = 'status-message show ' + type;
    status.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : 'exclamation'}-circle"></i> ${message}`;
    
    setTimeout(() => {
        status.classList.remove('show');
    }, 5000);
}

/**
 * Filter Buttons
 */
function setupFilterButtons() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            currentFilter = btn.dataset.filter;
            loadAds();
        });
    });
}

/**
 * Load and Display Ads
 */
async function loadAds() {
    const adsGrid = document.getElementById('adsGrid');
    const totalAdsEl = document.getElementById('totalAds');
    
    adsGrid.innerHTML = `
        <div class="loading-spinner">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading ads...</p>
        </div>
    `;
    
    try {
        // Add cache-busting timestamp to prevent stale data
        const timestamp = new Date().getTime();
        const response = await fetch(`actions/ad_actions.php?action=fetch&filter=${currentFilter}&_=${timestamp}`);
        const data = await response.json();
        
        if (data.success && data.ads.length > 0) {
            totalAdsEl.textContent = data.ads.length;
            displayAds(data.ads);
        } else {
            adsGrid.innerHTML = `
                <div class="loading-spinner">
                    <i class="fas fa-inbox" style="font-size: 64px; color: #cbd5e1;"></i>
                    <p>No ads found</p>
                </div>
            `;
            totalAdsEl.textContent = '0';
        }
    } catch (error) {
        adsGrid.innerHTML = `
            <div class="loading-spinner">
                <i class="fas fa-exclamation-triangle" style="color: #ef4444;"></i>
                <p>Failed to load ads</p>
            </div>
        `;
    }
}

function displayAds(ads) {
    const adsGrid = document.getElementById('adsGrid');
    
    adsGrid.innerHTML = ads.map(ad => `
        <div class="ad-card" data-id="${ad.id}">
            <img src="${ad.image_url}" alt="${ad.title}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 400 300%22%3E%3Crect fill=%22%23e5e7eb%22 width=%22400%22 height=%22300%22/%3E%3Ctext fill=%22%239ca3af%22 x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 dy=%22.3em%22 font-size=%2224%22%3EImage%3C/text%3E%3C/svg%3E'" />
            <div class="ad-content">
                <div class="ad-title">${escapeHtml(ad.title)}</div>
                <div class="ad-body">${escapeHtml(ad.body)}</div>
                <div class="ad-meta">
                    <span>${formatDate(ad.created_at)}</span>
                    <span class="ad-badge ${ad.is_active ? 'active' : 'inactive'}">
                        ${ad.is_active ? 'Active' : 'Inactive'}
                    </span>
                </div>
                <div class="ad-stats" style="font-size: 11px; color: #9ca3af; margin-bottom: 12px;">
                    <i class="fas fa-mouse-pointer"></i> ${ad.click_count || 0} clicks
                </div>
                <div class="ad-actions">
                    <button class="btn-small btn-edit" onclick="editAd(${ad.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn-small btn-toggle" onclick="toggleAd(${ad.id})">
                        <i class="fas fa-toggle-${ad.is_active ? 'on' : 'off'}"></i> ${ad.is_active ? 'Hide' : 'Show'}
                    </button>
                    <button class="btn-small btn-delete" onclick="deleteAd(${ad.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * Edit Ad
 */
async function editAd(id) {
    try {
        const response = await fetch(`actions/ad_actions.php?action=fetch&filter=all`);
        const data = await response.json();
        
        const ad = data.ads.find(a => a.id == id);
        if (!ad) return;
        
        // Populate edit form
        document.getElementById('editAdId').value = ad.id;
        document.getElementById('editTitle').value = ad.title;
        document.getElementById('editBody').value = ad.body;
        document.getElementById('editMessage').value = ad.message;
        document.getElementById('editCurrentImage').src = ad.image_url;
        
        // Show modal
        document.getElementById('editModal').classList.add('show');
        
        // Setup edit form submission
        const editForm = document.getElementById('editForm');
        editForm.onsubmit = async function(e) {
            e.preventDefault();
            
            const formData = new FormData(editForm);
            formData.append('action', 'update');
            
            try {
                const response = await fetch('actions/ad_actions.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    closeEditModal();
                    loadAds();
                    showStatus('success', data.message);
                } else {
                    alert(data.message);
                }
            } catch (error) {
                alert('Update failed: ' + error.message);
            }
        };
    } catch (error) {
        alert('Failed to load ad details');
    }
}

function closeEditModal() {
    document.getElementById('editModal').classList.remove('show');
}

/**
 * Toggle Ad Status
 */
async function toggleAd(id) {
    try {
        const response = await fetch('actions/ad_actions.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=toggle&id=${id}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Reload all ads to reflect the change
            await loadAds();
            showStatus('success', data.message);
        } else {
            alert(data.message);
        }
    } catch (error) {
        console.error('Toggle error:', error);
        alert('Toggle failed: ' + error.message);
    }
}

/**
 * Delete Ad
 */
async function deleteAd(id) {
    if (!confirm('Are you sure you want to delete this ad? This action cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch('actions/ad_actions.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=delete&id=${id}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadAds();
            showStatus('success', data.message);
        } else {
            alert(data.message);
        }
    } catch (error) {
        alert('Delete failed: ' + error.message);
    }
}

/**
 * Helper Functions
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    
    return date.toLocaleDateString();
}

// Close modal on outside click
document.addEventListener('click', function(e) {
    const modal = document.getElementById('editModal');
    if (e.target === modal) {
        closeEditModal();
    }
});
