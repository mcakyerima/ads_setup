<?php

/**
 * API Endpoint for Mobile App
 * Handles GET, POST, PUT, DELETE requests for ads
 */

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once '../config.php';
require_once '../includes/db.php';

// Fallback for BASE_URL if not defined in config.php
if (!defined('BASE_URL')) {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $path = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/');
    define('BASE_URL', $protocol . '://' . $host . $path);
}

$method = $_SERVER['REQUEST_METHOD'];
$requestUri = $_SERVER['REQUEST_URI'];

// Parse request
$path = parse_url($requestUri, PHP_URL_PATH);
$pathParts = explode('/', trim($path, '/'));

try {
    switch ($method) {
        case 'GET':
            handleGet($pdo);
            break;

        case 'POST':
            handlePost($pdo);
            break;

        case 'PUT':
            handlePut($pdo, $pathParts);
            break;

        case 'DELETE':
            handleDelete($pdo, $pathParts);
            break;

        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

/**
 * GET - Fetch all active ads
 */
function handleGet($pdo)
{
    $stmt = $pdo->prepare("
        SELECT id, title, body, message, image, is_active, click_count, created_at, updated_at
        FROM ads
        WHERE is_active = 1
        ORDER BY created_at DESC
    ");
    $stmt->execute();
    $ads = $stmt->fetchAll();

    // Format image URLs for mobile app
    foreach ($ads as &$ad) {
        // Construct full URL using BASE_URL constant
        $ad['image'] = BASE_URL . '/uploads/' . basename($ad['image']);
        $ad['isActive'] = (bool)$ad['is_active'];
        unset($ad['is_active']);
    }

    echo json_encode($ads);
}

/**
 * POST - Create new ad or increment click count
 */
function handlePost($pdo)
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

    // Check if this is a click tracking request
    $input = json_decode(file_get_contents('php://input'), true);
    if (isset($input['action']) && $input['action'] === 'click' && isset($input['ad_id'])) {
        handleAdClick($pdo, $input['ad_id']);
        return;
    }

    // Handle ad creation (multipart/form-data from admin panel)
    if (strpos($contentType, 'multipart/form-data') !== false) {
        handleAdCreation($pdo);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid content type']);
    }
}

/**
 * Handle ad creation with image upload
 */
function handleAdCreation($pdo)
{
    $title = $_POST['title'] ?? '';
    $body = $_POST['body'] ?? '';
    $message = $_POST['message'] ?? '';
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    // Validate inputs
    if (empty($title) || empty($body) || empty($message)) {
        http_response_code(400);
        echo json_encode(['error' => 'Title, body, and message are required']);
        return;
    }

    // Handle image upload
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['error' => 'Image is required']);
        return;
    }

    $file = $_FILES['image'];
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];

    if (!in_array($file['type'], $allowedTypes)) {
        http_response_code(400);
        echo json_encode(['error' => 'Only JPG, PNG, and GIF images are allowed']);
        return;
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        http_response_code(400);
        echo json_encode(['error' => 'Image size must be less than 5MB']);
        return;
    }

    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('ad_') . '_' . time() . '.' . $extension;
    $uploadPath = __DIR__ . '/../uploads/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to upload image']);
        return;
    }

    // Insert into database
    $stmt = $pdo->prepare("
        INSERT INTO ads (title, body, message, image, is_active)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$title, $body, $message, $filename, $isActive]);

    $adId = $pdo->lastInsertId();

    // Fetch the created ad
    $stmt = $pdo->prepare("SELECT * FROM ads WHERE id = ?");
    $stmt->execute([$adId]);
    $ad = $stmt->fetch();

    $ad['image'] = UPLOADS_URL . '/' . basename($ad['image']);
    $ad['isActive'] = (bool)$ad['is_active'];

    http_response_code(201);
    echo json_encode([
        'success' => true,
        'message' => 'Ad created successfully',
        'ad' => $ad
    ]);
}

/**
 * Track ad clicks
 */
function handleAdClick($pdo, $adId)
{
    $stmt = $pdo->prepare("UPDATE ads SET click_count = click_count + 1 WHERE id = ?");
    $stmt->execute([$adId]);

    echo json_encode([
        'success' => true,
        'message' => 'Click tracked'
    ]);
}

/**
 * PUT - Update ad or toggle status
 */
function handlePut($pdo, $pathParts)
{
    $input = json_decode(file_get_contents('php://input'), true);

    // Extract ID from path (e.g., /api/ads/123)
    $adId = null;
    foreach ($pathParts as $i => $part) {
        if ($part === 'ads' && isset($pathParts[$i + 1])) {
            $adId = $pathParts[$i + 1];
            break;
        }
    }

    if (!$adId) {
        http_response_code(400);
        echo json_encode(['error' => 'Ad ID is required']);
        return;
    }

    // Check if this is a toggle request
    if (isset($input['action']) && $input['action'] === 'toggle') {
        $stmt = $pdo->prepare("UPDATE ads SET is_active = NOT is_active WHERE id = ?");
        $stmt->execute([$adId]);

        echo json_encode([
            'success' => true,
            'message' => 'Ad status toggled'
        ]);
        return;
    }

    // Handle full update
    $title = $input['title'] ?? null;
    $body = $input['body'] ?? null;
    $message = $input['message'] ?? null;

    if ($title && $body && $message) {
        $stmt = $pdo->prepare("
            UPDATE ads 
            SET title = ?, body = ?, message = ?
            WHERE id = ?
        ");
        $stmt->execute([$title, $body, $message, $adId]);

        echo json_encode([
            'success' => true,
            'message' => 'Ad updated successfully'
        ]);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid update data']);
    }
}

/**
 * DELETE - Delete ad
 */
function handleDelete($pdo, $pathParts)
{
    // Extract ID from path
    $adId = null;
    foreach ($pathParts as $i => $part) {
        if ($part === 'ads' && isset($pathParts[$i + 1])) {
            $adId = $pathParts[$i + 1];
            break;
        }
    }

    if (!$adId) {
        http_response_code(400);
        echo json_encode(['error' => 'Ad ID is required']);
        return;
    }

    // Get image filename before deleting
    $stmt = $pdo->prepare("SELECT image FROM ads WHERE id = ?");
    $stmt->execute([$adId]);
    $ad = $stmt->fetch();

    if ($ad) {
        // Delete image file
        $imagePath = __DIR__ . '/../uploads/' . basename($ad['image']);
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }

        // Delete from database
        $stmt = $pdo->prepare("DELETE FROM ads WHERE id = ?");
        $stmt->execute([$adId]);

        echo json_encode([
            'success' => true,
            'message' => 'Ad deleted successfully'
        ]);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Ad not found']);
    }
}
