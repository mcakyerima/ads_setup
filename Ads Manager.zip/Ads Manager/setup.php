<?php

/**
 * Database Setup Handler
 * Creates configuration file and initializes database
 */

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$db_host = $_POST['db_host'] ?? '';
$db_name = $_POST['db_name'] ?? '';
$db_user = $_POST['db_user'] ?? '';
$db_password = $_POST['db_password'] ?? '';
$whatsapp_number = $_POST['whatsapp_number'] ?? '';
$admin_username = trim($_POST['admin_username'] ?? '');
$admin_password = $_POST['admin_password'] ?? '';

// Validate inputs
if (empty($db_host) || empty($db_name) || empty($db_user)) {
    echo json_encode(['success' => false, 'message' => 'All fields except password are required']);
    exit;
}

if (empty($whatsapp_number)) {
    echo json_encode(['success' => false, 'message' => 'WhatsApp number is required']);
    exit;
}

if (empty($admin_username) || empty($admin_password)) {
    echo json_encode(['success' => false, 'message' => 'Admin username and password are required']);
    exit;
}

if (strlen($admin_password) < 6) {
    echo json_encode(['success' => false, 'message' => 'Admin password must be at least 6 characters']);
    exit;
}

// Test database connection
try {
    $dsn = "mysql:host=$db_host;charset=utf8mb4";
    $pdo = new PDO($dsn, $db_user, $db_password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create database if it doesn't exist
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

    // Connect to the database
    $dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";
    $pdo = new PDO($dsn, $db_user, $db_password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create ads table
    $createTable = "CREATE TABLE IF NOT EXISTS ads (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(60) NOT NULL,
        body VARCHAR(150) NOT NULL,
        message VARCHAR(200) NOT NULL,
        image VARCHAR(255) NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        click_count INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_active (is_active),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

    $pdo->exec($createTable);

    // Create settings table
    $createSettingsTable = "CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(50) UNIQUE NOT NULL,
        setting_value TEXT NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

    $pdo->exec($createSettingsTable);

    // Create admin users table
    $createAdminTable = "CREATE TABLE IF NOT EXISTS admin_users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

    $pdo->exec($createAdminTable);

    // Insert WhatsApp number
    $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('whatsapp_number', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->execute([$whatsapp_number, $whatsapp_number]);

    // Hash and insert admin user
    $hashedPassword = password_hash($admin_password, PASSWORD_DEFAULT);
    $adminStmt = $pdo->prepare("INSERT INTO admin_users (username, password) VALUES (?, ?) ON DUPLICATE KEY UPDATE password = ?");
    $adminStmt->execute([$admin_username, $hashedPassword, $hashedPassword]);

    // Create uploads directory
    $uploadsDir = __DIR__ . '/uploads';
    if (!is_dir($uploadsDir)) {
        mkdir($uploadsDir, 0755, true);
    }

    // Create .htaccess for uploads directory
    $htaccess = "# Secure uploads directory\n";
    $htaccess .= "<FilesMatch \"\\.(jpg|jpeg|png|gif)$\">\n";
    $htaccess .= "    Allow from all\n";
    $htaccess .= "</FilesMatch>\n";
    file_put_contents($uploadsDir . '/.htaccess', $htaccess);

    // Create config.php file
    $configContent = "<?php\n";
    $configContent .= "/**\n";
    $configContent .= " * Database Configuration\n";
    $configContent .= " * Auto-generated on " . date('Y-m-d H:i:s') . "\n";
    $configContent .= " */\n\n";
    $configContent .= "define('DB_HOST', '$db_host');\n";
    $configContent .= "define('DB_NAME', '$db_name');\n";
    $configContent .= "define('DB_USER', '$db_user');\n";
    $configContent .= "define('DB_PASSWORD', '$db_password');\n\n";

    // Add getBaseUrl function with fix for /api and /actions paths
    $configContent .= "// Determine base URL automatically\n";
    $configContent .= "function getBaseUrl() {\n";
    $configContent .= "    \$protocol = isset(\$_SERVER['HTTPS']) && \$_SERVER['HTTPS'] === 'on' ? 'https' : 'http';\n";
    $configContent .= "    \$host = \$_SERVER['HTTP_HOST'];\n\n";
    $configContent .= "    // Get script directory relative to document root\n";
    $configContent .= "    \$scriptDir = dirname(\$_SERVER['SCRIPT_NAME']);\n";
    $configContent .= "    \n";
    $configContent .= "    // Remove /api or /actions from the path if present\n";
    $configContent .= "    \$scriptDir = preg_replace('#/(api|actions)$#', '', \$scriptDir);\n\n";
    $configContent .= "    // For XAMPP (localhost) - usually script is in root\n";
    $configContent .= "    // For cPanel - usually script is in public_html or subdirectory\n";
    $configContent .= "    if (\$scriptDir === '/' || \$scriptDir === '\\\\') {\n";
    $configContent .= "        \$basePath = '';\n";
    $configContent .= "    } else {\n";
    $configContent .= "        \$basePath = rtrim(\$scriptDir, '/');\n";
    $configContent .= "    }\n\n";
    $configContent .= "    return \$protocol . '://' . \$host . \$basePath;\n";
    $configContent .= "}\n\n";

    // Define constants
    $configContent .= "// Define constants\n";
    $configContent .= "define('BASE_URL', getBaseUrl());\n";
    $configContent .= "define('UPLOADS_URL', BASE_URL . '/uploads');\n";
    $configContent .= "define('UPLOADS_DIR', __DIR__ . '/uploads');\n\n";

    // Create uploads directory if needed
    $configContent .= "// Create uploads directory if it doesn't exist\n";
    $configContent .= "if (!file_exists(UPLOADS_DIR)) {\n";
    $configContent .= "    mkdir(UPLOADS_DIR, 0755, true);\n\n";
    $configContent .= "    // Create .htaccess to protect uploads folder\n";
    $configContent .= "    \$htaccess = \"Order deny,allow\\nDeny from all\\n<FilesMatch \\\"\\\\.(jpg|jpeg|png|gif|webp)$\\\">\\n    Allow from all\\n</FilesMatch>\";\n";
    $configContent .= "    file_put_contents(UPLOADS_DIR . '/.htaccess', \$htaccess);\n";
    $configContent .= "}\n";
    $configContent .= "?>";

    file_put_contents(__DIR__ . '/config.php', $configContent);

    echo json_encode([
        'success' => true,
        'message' => 'Database configured successfully! Redirecting...'
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
