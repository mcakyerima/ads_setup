<?php

/**
 * Ad Landing Page with Open Graph Meta Tags
 * This page displays ad details and provides WhatsApp link with rich preview
 */

require_once 'config.php';
require_once 'includes/db.php';

// Get ad ID from URL
$adId = $_GET['id'] ?? null;

if (!$adId) {
    header('Location: index.php');
    exit;
}

// Fetch ad details
try {
    $stmt = $pdo->prepare("SELECT * FROM ads WHERE id = ? AND is_active = 1");
    $stmt->execute([$adId]);
    $ad = $stmt->fetch();

    if (!$ad) {
        header('Location: index.php');
        exit;
    }

    // Increment click count
    $updateStmt = $pdo->prepare("UPDATE ads SET click_count = click_count + 1 WHERE id = ?");
    $updateStmt->execute([$adId]);

    // Fetch WhatsApp number from settings
    $whatsappStmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'whatsapp_number' LIMIT 1");
    $whatsappStmt->execute();
    $whatsappRow = $whatsappStmt->fetch();
    $whatsappNumber = $whatsappRow ? $whatsappRow['setting_value'] : '2348066968620'; // fallback to default

    // Construct full image URL
    $imageUrl = BASE_URL . '/uploads/' . basename($ad['image']);
    $pageUrl = BASE_URL . '/ad-view.php?id=' . $adId;

    // WhatsApp sharing: Use custom message from admin, or fallback
    // This triggers WhatsApp rich preview with image, title and description
    $customMessage = !empty($ad['message']) ? $ad['message'] : "Hello! I would like to get more details about this offer: " . $ad['title'];
    $shareMessage = urlencode($customMessage);
    $whatsappUrl = "https://wa.me/{$whatsappNumber}?text={$shareMessage}%0A%0A{$pageUrl}";
} catch (PDOException $e) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Regular Meta Tags -->
    <title><?php echo htmlspecialchars($ad['title']); ?> - KimeData</title>
    <meta name="description" content="<?php echo htmlspecialchars($ad['body']); ?>">

    <!-- Open Graph / Facebook Meta Tags -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo $pageUrl; ?>">
    <meta property="og:title" content="<?php echo htmlspecialchars($ad['title']); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($ad['body']); ?>">
    <meta property="og:image" content="<?php echo $imageUrl; ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="<?php echo htmlspecialchars($ad['title']); ?>">

    <!-- Twitter Card Meta Tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="<?php echo $pageUrl; ?>">
    <meta name="twitter:title" content="<?php echo htmlspecialchars($ad['title']); ?>">
    <meta name="twitter:description" content="<?php echo htmlspecialchars($ad['body']); ?>">
    <meta name="twitter:image" content="<?php echo $imageUrl; ?>">

    <!-- WhatsApp Specific -->
    <meta property="og:site_name" content="KimeData">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            width: 100%;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .ad-image {
            width: 100%;
            height: 300px;
            object-fit: cover;
        }

        .ad-content {
            padding: 30px;
        }

        .ad-badge {
            display: inline-block;
            background: #0286FF;
            color: white;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 15px;
        }

        .ad-title {
            font-size: 28px;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 15px;
            line-height: 1.3;
        }

        .ad-body {
            font-size: 16px;
            color: #6b7280;
            line-height: 1.6;
            margin-bottom: 25px;
        }

        .stats {
            display: flex;
            gap: 20px;
            padding: 15px 0;
            border-top: 1px solid #e5e7eb;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 25px;
        }

        .stat-item {
            flex: 1;
            text-align: center;
        }

        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: #0286FF;
        }

        .stat-label {
            font-size: 12px;
            color: #9ca3af;
            text-transform: uppercase;
            margin-top: 5px;
        }

        .whatsapp-btn {
            display: block;
            width: 100%;
            background: #25D366;
            color: white;
            text-align: center;
            padding: 16px;
            border-radius: 12px;
            text-decoration: none;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(37, 211, 102, 0.3);
        }

        .whatsapp-btn:hover {
            background: #20ba5a;
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(37, 211, 102, 0.4);
        }

        .whatsapp-btn i {
            margin-right: 8px;
            font-size: 18px;
        }

        .share-section {
            margin-top: 20px;
            text-align: center;
        }

        .share-text {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 10px;
        }

        .share-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #f3f4f6;
            color: #374151;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .share-btn:hover {
            background: #e5e7eb;
        }

        @media (max-width: 640px) {
            .ad-title {
                font-size: 24px;
            }

            .ad-content {
                padding: 20px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <img src="<?php echo $imageUrl; ?>" alt="<?php echo htmlspecialchars($ad['title']); ?>" class="ad-image">

        <div class="ad-content">
            <span class="ad-badge">Special Offer</span>

            <h1 class="ad-title"><?php echo htmlspecialchars($ad['title']); ?></h1>

            <p class="ad-body"><?php echo nl2br(htmlspecialchars($ad['body'])); ?></p>

            <div class="stats">
                <div class="stat-item">
                    <div class="stat-value">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="stat-label"><?php echo date('d M Y', strtotime($ad['created_at'])); ?></div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">
                        <i class="fas fa-tag"></i>
                    </div>
                    <div class="stat-label">Special Offer</div>
                </div>
            </div>

            <a href="<?php echo $whatsappUrl; ?>" class="whatsapp-btn" target="_blank">
                <i class="fab fa-whatsapp"></i> Contact Us on WhatsApp
            </a>

            <div class="share-section">
                <p class="share-text">Share this offer</p>
                <a href="javascript:void(0)" onclick="copyLink()" class="share-btn" id="shareBtn">
                    <i class="fas fa-copy"></i> Copy Link
                </a>
            </div>
        </div>
    </div>

    <script>
        function copyLink() {
            const url = window.location.href;
            navigator.clipboard.writeText(url).then(() => {
                const btn = document.getElementById('shareBtn');
                const originalText = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-check"></i> Link Copied!';
                btn.style.background = '#dcfce7';
                btn.style.color = '#16a34a';

                setTimeout(() => {
                    btn.innerHTML = originalText;
                    btn.style.background = '#f3f4f6';
                    btn.style.color = '#374151';
                }, 2000);
            }).catch(err => {
                alert('Could not copy link. Please copy manually: ' + url);
            });
        }
    </script>
</body>

</html>